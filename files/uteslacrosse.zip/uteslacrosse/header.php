<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8) ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title( '|', true, 'right' ); ?></title>
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_uri(); ?>">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500,700,400italic,500italic|Roboto+Condensed:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/cycle.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/jquery.cycle2.carousel.min.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/slicknav.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/js/functions.js"></script>

    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	
	<div class="header">
	    <div class="container">
	        <div class="logo">
				<a href="<?php bloginfo('url'); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/logo.png" alt="Logo" /></a>
			</div>
			<div class="logo-text"><a href="<?php bloginfo('url'); ?>">Utah Lacrosse</a></div>
	        <div class="social-container">
				<div class="social-icon">
					<a href="http://www.twitter.com/utahlacrosse" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				</div>
				<div class="social-icon">
					<a href="http://www.facebook.com/utahlacrosse" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				</div>
				<div class="social-icon">
					<a href="http://www.instagram.com/utahlacrosse" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				</div>
				<div class="social-icon">
					<a href="http://www.snapchat.com/utahlacrosse" target="_blank"><i class="fa fa-snapchat" aria-hidden="true"></i></a>
				</div>
	        </div>
	    </div>
		<?php wp_nav_menu( array( 'theme_location' => 'main_nav','depth' => 2) ); ?>
	    <div class="slicknav"></div>
	</div><!-- /.header -->
	
	<div class="page-content">

