<?php
add_theme_support( 'post-thumbnails' );

function register_custom_menu() {
    register_nav_menu('main_nav', __('Main Menu')); // repeat this for more navs
	register_nav_menu('footer_nav', __('Footer Menu'));
}

require_once locate_template('custom_post_type.class.php');

add_theme_support( 'html5', array( 'search-form' ) );