	</div><!-- /.page-content -->
	<footer class="footer">
		<div class="footer-bar">
			<?php wp_nav_menu( array( 'theme_location' => 'footer_nav','menu_class' => 'footer-menu', 'depth' => 1) ); ?>
		</div><!-- /.footer-bar -->
	</footer><!-- /.footer -->

<?php wp_footer(); ?>

</body>
</html>
