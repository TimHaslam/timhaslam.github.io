<?php get_header(); ?>

<table>
	<thead>
		<tr>
			<th>Name</th>
			<th>GP</th>
			<th>GS</th>
			<th>Goals</th>
			<th>Assists</th>
			<th>Face-Offs</th>
		</tr>
	</thead>
	<tbody>
<?php while(the_repeater_field('stats')): ?>
	<?php 

	$player_name = get_sub_field('roster_id');

	if( $player_name ): ?>

	<ul>    

	<?php foreach( $player_name as $player): // variable must be called $post (IMPORTANT) 

	    setup_postdata($p); ?>

	        <tr>
				
				<?php var_dump($player_name)?>
				<td><?php echo $player_name->post_title; ?></td>
				<td>GP</td>
				<td>GS</td>
				<td>Goals</td>
				<td>Assists</td>
				<td>Face-Offs</td>
			</tr>
	<?php endforeach; ?>
		
<?php endwhile;?>
	</tbody>
</table>
<?php get_footer(); ?>