$( document ).ready(function() {
			
	$(function() {
		  $('a[href*=#]:not([href=#])').click(function() {
		    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
		      var target = $(this.hash);
		      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
		      if (target.length) {
		        $('html,body').animate({
		          scrollTop: target.offset().top - 150
		        }, 1000);
		        return false;
		      }
		    }
		  });
		});
	
	var $document = $(document),
	    $element = $('.header'),
	    className = 'hasScrolled';

	$document.scroll(function() {
	  $element.toggleClass(className, $document.scrollTop() >= 1);
	});
		
	$('.menu').slicknav({
		prependTo:'.slicknav'
	});

	
	$('.search-toggle').on('click', function(event) {
		event.preventDefault();

		$('.search').toggleClass('open');
	});
	
	
	
	$('.hero-slider-container').cycle({
	    speed: 600,
	    manualSpeed: 100,
		pager: '.cycle-pager',
		slides: '> .hero-slider',
		next:'.cycle-buttons .cycle-next',
		prev:'.cycle-buttons .cycle-prev',
		pauseOnHover: true
	});
	
		
    // generate mobile version for each table
    $('table').each(function() {
      var table = $(this); // cache table object
      var head = table.find('thead th');
      var rows = table.find('tbody tr').clone(); // appending afterwards does not break original table
      // create new table
      var newtable = $(
        '<table class="generated_for_mobile">' +
        '  <tbody>' +
        '  </tbody>' +
        '</table>'
      );
      // cache tbody where we'll be adding data
      var newtable_tbody = newtable.find('tbody');
      rows.each(function(i) {
        var cols = $(this).find('td');
        var classname = i % 2 ? 'even' : 'odd';
        cols.each(function(k) {
          var new_tr = $('<tr class="' + classname + '"></tr>').appendTo(newtable_tbody);
          new_tr.append(head.clone().get(k));
          new_tr.append($(this));
        });
      });
      $(this).after(newtable);
    });
	
	
	var cycle_check, cycle_init, cycle_timer, cycle_next, cycle_active = 0;

	(cycle_check = function() {
	    var width = $(window).width(); // Checking size again after window resize
	    if ( width < 600 && $( ".content-thumbs" ).attr( "data-cycle-carousel-visible" ) !== "1" ) {
	        $( ".content-thumbs" ).cycle( "destroy" ).attr( "data-cycle-carousel-visible", "1" );
	        cycle_init( 1 );
	    } else if ( width > 600 && $( ".content-thumbs" ).attr( "data-cycle-carousel-visible" ) !== "5" ) {
	        $( ".content-thumbs" ).cycle( "destroy" ).attr( "data-cycle-carousel-visible", "5" );
	        cycle_init( 5 );
	    }
	})();

	function cycle_init( visibleSlides ) {
	    $( ".content-thumbs" ).cycle({
	        fx: 'carousel',
	        slides: '> .content-thumb-container',
	        next: '.content-thumbs .cycle-next',
	        prev: '.content-thumbs .cycle-prev',
	        startingSlide: cycle_active
	    });
	}

	var $nav = $('ul.menu > li');
		$nav.hover(
			function() {
	            $(this).children('a').addClass('hovered')
				$('ul', this).stop(true, true).slideDown('fast');
			},
			function() {
	            $(this).children('a').removeClass('hovered')
				$('ul', this).slideUp('fast');
			}
		);
});