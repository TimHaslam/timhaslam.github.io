<?php

/**
 * Base Custom Post Type Class and Aggregator
 *
 * a heavily modified version of SD Regsiter Post Type 1.3 by Matt Wiebe
 * http://somadesign.ca/
 *
 */
if ( ! class_exists('CustomPostType')) {

class CustomPostType
{

	protected $post_type = 'custom_post';
	protected $post_slug;
	protected $singular; // for labels
	protected $plural; // for labels
	protected $menu_title; // for labels
	protected $args;

	protected $defaults = array(
		'labels' => array( ), // this can be overridden by setting it, but if it's empty, defaults will be used
		'description' => '',
		'public' => true,
		'publicly_queryable' => true,
		'exclude_from_search' => false,
		'show_ui' => true,
		'menu_position' => 5,
		'menu_icon' => null,
		'capability_type' => 'page',
#		'capabilities' => array( ),
		'hierarchical' => true,
		'supports' => array(
			'title',
			'editor',
#			'author',
			'thumbnail',
#			'excerpt',
#			'trackbacks',
#			'custom-fields',
#			'comments',
			'revisions',
			'page-attributes',
		),
		'taxonomies' => array(
			'category',
		),
		'has_archive' => true,
		'rewrite' => true, /** array(
			'slug' => 'slug', // '/slug/[post_slug/'
			'with_front' => true, // if your permalink structure is /blog/, then your links will be: false->/news/, true->/blog/news/
			'feeds' => true,
			'pages' => true,
		), //*/
		'query_var' => true,
		'can_export' => true,
		'show_in_nav_menus' => true,
	);


	public function __construct($post_type = null, $args = array( ), $post_slug = false)
	{
		// generate/store our names
		if ($post_type) {
			$this->post_type = $post_type;
		}

		if (empty($this->post_slug)) {
			$this->post_slug = ( ! empty($post_slug)) ? $post_slug : $this->post_type.'s';
		}

		$this->set_defaults( );
		$this->args = array_merge($this->defaults, $args);

		// run the stuff
		$this->add_actions( );
		$this->add_filters( );
	}


	private function set_defaults( )
	{
		$cpt_vars = get_class_vars(__CLASS__);

		if (isset($cpt_vars['defaults']) && ! empty($cpt_vars['defaults'])) {
			$this->defaults = array_merge($cpt_vars['defaults'], $this->defaults);
		}

		$post_type = ucwords(str_replace(array('_', '-'), ' ', $this->post_type));
		$post_slug = ucwords(str_replace(array('_', '-'), ' ', $this->post_slug));

		if ( ! $this->defaults) {
			$this->defaults = self::$_defaults;
		}

		$this->singular = ( ! empty($this->singular)) ? $this->singular : $post_type;
		$this->plural = ( ! empty($this->plural)) ? $this->plural : $post_slug;
		$this->menu_title = ( ! empty($this->menu_title)) ? $this->menu_title : $this->plural;

		$this->defaults['labels'] = ! empty($this->defaults['labels']) ? $this->defaults['labels'] : array(
			'name' => _x($this->plural, 'post type general name'), // Posts
			'singular_name' => _x($this->singular, 'post type singular name'), // Post
			'add_new' => _x('Add New', strtolower($post_slug)), // Add New
			'add_new_item' => __('Add New '.$this->singular), // Add New Post
			'edit_item' => __('Edit '.$this->singular), // Edit Post
			'new_item' => __('New '.$this->singular), // New Post
			'view_item' => __('View '.$this->singular), // View Post
			'search_items' => __('Search '.$this->menu_title), // Search Posts
			'not_found' =>  __('No '.$this->plural.' found'), // No Posts found
			'not_found_in_trash' => __('No '.$this->plural.' found in Trash'), // No Posts found in Trash
			'parent_item_colon' => ':', // Parent Page: (hierarchical only)
			'menu_name' => _x($this->menu_title, 'post type menu name'), // Posts (in menu)
		);

		$this->defaults['has_archive'] = (true == $this->defaults['has_archive']) ? $this->post_slug : $this->defaults['has_archive'];
		$this->defaults['rewrite'] = (true == $this->defaults['rewrite']) ? array('slug' => $this->post_slug) : $this->defaults['rewrite'];
		$this->defaults['register_meta_box_cb'] = ( ! isset($this->defaults['register_meta_box_cb'])) ? array($this, 'admin_init') : $this->defaults['register_meta_box_cb'];
	}


	public function get_post_type( )
	{
		return $this->post_type;
	}


	public function add_actions( )
	{
		add_action('init', array($this, 'register_post_type'));
		add_action('template_redirect', array($this, 'context_fixer'));
	}


	public function add_filters( )
	{
		add_filter('generate_rewrite_rules', array($this, 'add_rewrite_rules'));
		add_filter('template_include', array($this, 'template_include'));
		add_filter('body_class', array($this, 'body_classes'));

		// sortable columns
		add_filter('manage_edit-'.$this->post_type.'_sortable_columns', array($this, 'sort_columns'));
		add_filter('request', array($this, 'fix_sort_columns'));
	}


	public function context_fixer( )
	{
		if (get_query_var('post_type') == $this->post_type) {
			global $wp_query;
			$wp_query->is_home = false;
		}
	}


	public function register_post_type( )
	{
		register_post_type($this->post_type, $this->args);

		// if title and editor are not supported, we need to manually remove them
		if ( ! in_array('title', $this->args['supports'])) {
			remove_post_type_support($this->post_type, 'title');
		}

		if ( ! in_array('editor', $this->args['supports'])) {
			remove_post_type_support($this->post_type, 'editor');
		}

		add_filter('manage_edit-'.$this->post_type.'_columns', array($this, 'edit_columns'));
	}


	public function template_include($template)
	{
		if (get_query_var('post_type') == $this->post_type) {
			if (is_single( )) {
				if ($single = locate_template(array($this->post_type.'/single.php'))) {
					return $single;
				}
			}
			else { // loop
				return locate_template(array(
					$this->post_type.'/index.php',
					$this->post_type.'.php',
					'index.php',
				));
			}
		}

		return $template;
	}


	public function body_classes($c)
	{
		if (get_query_var('post_type') === $this->post_type) {
			$c[] = $this->post_type;
			$c[] = 'type-'.$this->post_type;
		}
		return $c;
	}


	// this sets what columns are to be shown on the index page
	public function edit_columns( )
	{
		// this is a placeholder for more in-depth child classes
		// or, alternatively, you can pass in a global function name into
		// the edit_columns argument

		if ( ! empty($this->args['edit_columns']) && function_exists($this->args['edit_columns'])) {
			${$this->args['edit_columns']}( );
		}
		else {
			$posts_columns = array();

			$posts_columns['cb'] = '<input type="checkbox" />';

			/* translators: manage posts column name */
			$posts_columns['title'] = _x( 'Title', 'column name' );

			if ( post_type_supports( $this->post_type, 'author' ) )
				$posts_columns['author'] = __( 'Author' );

			if ( empty( $this->post_type ) || is_object_in_taxonomy( $this->post_type, 'category' ) )
				$posts_columns['categories'] = __( 'Categories' );

			if ( empty( $this->post_type ) || is_object_in_taxonomy( $this->post_type, 'post_tag' ) )
				$posts_columns['tags'] = __( 'Tags' );

			$post_status = !empty( $_REQUEST['post_status'] ) ? $_REQUEST['post_status'] : 'all';
			if ( post_type_supports( $this->post_type, 'comments' ) && !in_array( $post_status, array( 'pending', 'draft', 'future' ) ) )
				$posts_columns['comments'] = '<div class="vers"><img alt="' . esc_attr__( 'Comments' ) . '" src="' . esc_url( admin_url( 'images/comment-grey-bubble.png' ) ) . '" /></div>';

			$posts_columns['date'] = __( 'Date' );

			$posts_columns = apply_filters( "manage_{$this->post_type}_posts_columns", $posts_columns );

			return $posts_columns;
		}
	}


	public function add_rewrite_rules( )
	{
		// don't know exactly what this does, but WP
		// was throwing errors looking for it
	}


	public function admin_init( )
	{
		// this is a placeholder for more in-depth child classes
		// or, alternatively, you can pass in a global function name into
		// the admin_init argument

		if ( ! empty($this->args['admin_init']) && function_exists($this->args['admin_init'])) {
			return ${$this->args['admin_init']}( );
		}
	}


	public function save_data( )
	{
		// this is a placeholder for more in-depth child classes
		// or, alternatively, you can pass in a global function name into
		// the save_data argument

		if ( ! empty($this->args['save_data']) && function_exists($this->args['save_data'])) {
			return ${$this->args['save_data']}( );
		}
	}


	// this sets how to show the data for each of the given columns in the edit_columns method
	public function custom_columns($column)
	{
		// this is a placeholder for more in-depth child classes
		// or, alternatively, you can pass in a global function name into
		// the custom_columns argument

		if ( ! empty($this->args['custom_columns']) && function_exists($this->args['custom_columns'])) {
			return ${$this->args['custom_columns']}($column);
		}
	}


	// this sets how to sort the data for each of the given columns in the edit_columns method
	public function sort_columns($columns)
	{
		// this is a placeholder for more in-depth child classes
		// or, alternatively, you can pass in a global function name into
		// the sort_columns argument

		if ( ! empty($this->args['sort_columns']) && function_exists($this->args['sort_columns'])) {
			return ${$this->args['sort_columns']}($columns);
		}

		return $columns;
	}


	// this fixes how to sort the data for each of the given columns in the edit_columns method
	// in case it's not a simple field sort
	public function fix_sort_columns($args)
	{
		// this is a placeholder for more in-depth child classes
		// or, alternatively, you can pass in a global function name into
		// the fix_sort_columns argument

		if ( ! empty($this->args['fix_sort_columns']) && function_exists($this->args['fix_sort_columns'])) {
			return ${$this->args['fix_sort_columns']}($args);
		}

		return $args;
	}


	/* helper functions */

	protected function grab_hierarchical_array( )
	{
		// grab all the entries
		$items = get_pages(array(
			'sort_column' => 'menu_order',
			'sort_order' => 'ASC',
			'post_type' => $this->post_type,
		));

		$return = array( );
		foreach ($items as $item) {
			if (0 == $item->post_parent) {
				$cur_parent = $item->post_title;
				$return[$cur_parent] = array( );
			}
			else {
				$return[$cur_parent][$item->ID] = $item->post_title;
			}
		}

		return $return;
	}

} // end CustomPostType class

} // end class exists test


/**
 * Custom Post Type Registry
 *
 * this helps with dealing with more complex CPTs
 * that require the use of the save_post action,
 * and the manage_posts/pages_custom_column actions
 *
 */
if ( ! class_exists('CPTRegistry')) {

class CPTRegistry
{

	static private $_instance;

	protected $regsitry = array( );


	private function __construct( )
	{
		// add the actions this thing was built for
		add_action('save_post', array($this, 'master_custom_save_switch'));
		add_action('manage_posts_custom_column', array($this, 'master_custom_columns_switch'));
		add_action('manage_pages_custom_column', array($this, 'master_custom_columns_switch'));
	}


	/** static public function get_instance
	 *		Returns the singleton instance
	 *		of the MySQL Object as a reference
	 *
	 * @param array optional configuration array
	 * @action optionally creates the instance
	 * @return MySQL Object reference
	 */
	static public function get_instance( )
	{
		if (is_null(self::$_instance)) {
			$c = __CLASS__;
			self::$_instance = new $c( );
		}

		return self::$_instance;
	}


	// Prevent users from cloning the instance
	public function __clone( )
	{
		trigger_error('Clone is not allowed.', E_USER_ERROR);
	}


	static public function register($post_type, $args = array( ), $post_slug = false)
	{
		$_this = self::get_instance( );
		return $_this->_register($post_type, $args, $post_slug);
	}


	private function _register($post_type, $args = array( ), $post_slug = false)
	{
		if (('CPT' == substr($post_type, 0, 3)) && class_exists($post_type)) {
			$CPT = new $post_type( );
			$this->registry[$CPT->get_post_type( )] = $CPT;
		}
		else {
			$CPT = new CustomPostType($post_type, $args, $post_slug);
			$this->registry[$post_type] = $CPT;
		}

		return $CPT;
	}


	public function master_custom_save_switch( )
	{
		// skip if it's an autosave
		// autosave doesn't send everything and if it doesn't
		// send everything, things get deleted
		if ( ! isset($_POST['action']) || (0 !== strcmp('editpost', $_POST['action']))) {
			return;
		}

		if (isset($_POST['post_type']) && ! empty($this->registry[$_POST['post_type']])) {
			$this->registry[$_POST['post_type']]->save_data( );
		}
	}


	public function master_custom_columns_switch($column)
	{
		global $post;

		if (isset($post->post_type) && ! empty($this->registry[$post->post_type])) {
			$this->registry[$post->post_type]->custom_columns($column);
		}
	}

} // end CPTRegistry class

} // end class exists test


/**********************************************************\
 *
 *    HELPER FUNCTIONS
 *
\**********************************************************/


// a helper function to allow quick, painless class instantiation
if ( ! function_exists('custom_post_type') && class_exists('CustomPostType') && class_exists('CPTRegistry')) {
	function custom_post_type($post_type, $args = array( ), $post_slug = false) {
		return CPTRegistry::register($post_type, $args, $post_slug);
	}
}


// a helper snippit that will search the containing dir for cpt.__.php prefixed files
// and automagically include them
function include_cpt_files( ) {
	// open the current dir
	$dh = opendir(dirname(__FILE__));

	$filelist = array( );
	while (false !== ($file = readdir($dh))) {
		if (preg_match('/^cpt\..*\.?php$/i', $file)) { // scanning for cpt.__.php files only
			// if we found one of those files, include it, the rest happens by magic
			include $file;
		}
	}

	closedir($dh);
}

include_cpt_files( );





/**********************************************************\
 *
 *    MISC FUNCTIONS
 *
\**********************************************************/


function make_checkbox_list($name, $options, $values) {
	if (empty($options) || ! is_array($options)) {
		return false;
	}

	if (empty($values)) {
		$values = array( );
	}
	$values = (array) $values;

	$html = '<ul>';

	foreach ($options as $value => $key) {
		$checked = '';
		if (in_array($value, $values)) {
			$checked = 'checked="checked"';
		}

		$html .= '<li><label><input type="checkbox" name="'.$name.'[]" value="'.$value.'" '.$checked.' /> '.$key.'</label></li>';
	}

	$html .= '</ul>';

	return $html;
}


function make_select_options($options, $selected = null) {
	if (empty($options) || ! is_array($options)) {
		return false;
	}

	$selected = (array) $selected;

	$html = '';

	foreach ($options as $key => $value) {
		if (is_array($value)) {
			$html .= '<optgroup label="'.$key.'">';
			$html .= make_select_options($value, $selected);
			$html .= '</optgroup>';
		}
		else {
			$sel = (in_array($key, $selected) ? ' selected="selected"' : '');
			$html .= '<option value="'.$key.'"'.$sel.'>'.$value.'</option>';
		}
	}

	return $html;
}


function my_round($val, $closest) {
	$closest = (int) $closest;

	if (1 >= $closest) {
		return (int) round($val);
	}

	return (int) (round($val / $closest) * $closest);
}


if ( ! function_exists('call')) {
/** function call [dump] [debug]
 *		This function is for debugging only
 *		Outputs given var to screen
 *		or, if no var given, outputs stars to note position
 *
 * @param mixed optional var to output
 * @param bool optional bypass debug value and output anyway
 * @action outputs var to screen
 * @return void
 */
function call($var = 'Th&F=xUFucreSp2*ezAhe=ApuPR*$axe', $bypass = false, $show_from = true, $error = false)
{
	if ((( ! defined('DEBUG') || ! DEBUG) || ! empty($GLOBALS['NODEBUG'])) && ! (bool) $bypass) {
		return false;
	}

	if ('Th&F=xUFucreSp2*ezAhe=ApuPR*$axe' === $var) {
		$contents = '<span style="font-size:larger;font-weight:bold;color:red;">--==((OO88OO))==--</span>';
	}
	else {
		// begin output buffering so we can escape any html
		// and print_r is better at catching recursion than var_export
		ob_start( );

		if ((is_string($var) && ! preg_match('/^\\s*$/', $var))) { // non-whitespace strings
			print_r($var);
		}
		else {
			if ( ! function_exists('xdebug_disable')) {
				if (is_array($var) || is_object($var)) {
					print_r($var);
				}
				else {
					var_dump($var);
				}
			}
			else {
				var_dump($var);
			}
		}

		// end output buffering and output the result
		if ( ! function_exists('xdebug_disable')) {
			$contents = htmlentities(ob_get_contents( ));
		}
		else {
			$contents = ob_get_contents( );
		}

		ob_end_clean( );
	}

	$j = 0;
	$html = '';
	$debug_funcs = array('dump', 'debug');
	if ((bool) $show_from) {
		$called_from = debug_backtrace( );

		if (isset($called_from[$j + 1]) && in_array($called_from[$j + 1]['function'], $debug_funcs)) {
			++$j;
		}

		$file0 = substr($called_from[$j]['file'], strlen($_SERVER['DOCUMENT_ROOT']));
		$line0 = $called_from[$j]['line'];

		$called = '';
		if (isset($called_from[$j + 1]['file'])) {
			$file1 = substr($called_from[$j + 1]['file'], strlen($_SERVER['DOCUMENT_ROOT']));
			$line1 = $called_from[$j + 1]['line'];
			$called = "{$file1} : {$line1} called ";
		}
		elseif (isset($called_from[$j + 1]['class'])) {
			$called = $called_from[$j + 1]['class'].$called_from[$j + 1]['type'].$called_from[$j + 1]['function'].' called ';
		}

		$html = "<strong>{$called}{$file0} : {$line0}</strong>\n";
	}

	$color = '#000';
	if ($error) {
		$color = '#F00';
	}

	echo "\n\n<pre style=\"background:#FFF;color:{$color};font-size:larger;\">{$html}{$contents}\n<hr /></pre>\n\n";
}
}

if ( ! function_exists('dump')) {
function dump($var = 'Th&F=xUFucreSp2*ezAhe=ApuPR*$axe', $bypass = false, $show_from = true, $new_window = false, $error = false) { call($var, $bypass, $show_from, $new_window, $error); }
}

if ( ! function_exists('debug')) {
function debug($var = 'Th&F=xUFucreSp2*ezAhe=ApuPR*$axe', $bypass = true, $show_from = true, $new_window = false, $error = false) { call($var, $bypass, $show_from, $new_window, $error); }
}