<?php get_header(); ?>
	<div class="hero-slider-container" data-cycle-auto-height="container">
	<?php while(the_repeater_field('hero_slider')): ?>
		<?php $has_image_hero_slider = get_sub_field('image'); ?>
		<div class="section hero-slider" style="background-image:url('<?php echo $has_image_hero_slider['url']; ?>'); ?>" >
			<div class="hero-slider-box">
				<div class="hero-slider-title"><a href="<?php the_sub_field('hero_link'); ?>"><?php the_sub_field('hero_title'); ?></a></div>
				<div class="hero-slider-text"><?php the_sub_field('hero_text'); ?></div>
				<div class="hero-slider-link"><a href="<?php the_sub_field('hero_link'); ?>">Read More</a></div>
			</div>
		</div>
	<?php endwhile;?>
		<div class="cycle-buttons">
			<div class="cycle-prev">Prev</div>
			<div class="cycle-next">Next</div>
		</div>
	</div>
	
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

<?php get_footer(); ?>