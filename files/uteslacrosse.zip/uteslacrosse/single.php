<?php get_header(); ?>

Test

<?php get_footer(); ?>