<?php

/**********************************************************\
 *
 *    Games CUSTOM POST TYPE
 *
\**********************************************************/

class CPTGames extends CustomPostType
{

	protected $post_type = 'games';
	protected $post_slug = 'game';
	protected $defaults = array(
			'menu_position' => 4,
			'capability_type' => 'post',
			'hierarchical' => false,
			'labels' => array(
				'name' => 'Games',
				'singular_name' => 'Games'
			),
			'supports' => array(
				'title',
			),
			'exclude_from_search' => false,
			//'taxonomies' => array('directory'),
			'has_archive' => false,
		);

	public function edit_columns( )
	{
		$columns = array(
			'cb' => '<input type="checkbox" />',
			'title' => 'Title',
		);

		return $columns;
	}

} // end of CPTTeam class

custom_post_type('CPTGames');

//add_action( 'init', 'build_taxonomies_areas_of_expertise', 0 );  
//function build_taxonomies_areas_of_expertise() {  
//    register_taxonomy(  
//        'areas_of_expertise',  
//        array( 'directory' ),  // this is the custom post type(s) I want to use this taxonomy for
//        array(  
//                'hierarchical' => true,  
//                'label' => 'Areas of Expertise',  
//                'query_var' => true,  
//                'rewrite' => true  
//            )
//
//    );  
//};
//add_action( 'init', 'build_taxonomies_departments', 0 );  
//function build_taxonomies_departments() {  
//    register_taxonomy(  
//        'departments',  
//        array( 'directory' ),  // this is the custom post type(s) I want to use this taxonomy for
//        array(  
//                'hierarchical' => true,  
//                'label' => 'Departments',  
//                'query_var' => true,  
//                'rewrite' => true  
//            )
//
//    );  
//};